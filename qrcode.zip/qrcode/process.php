<?php
session_start();
include 'connection.php';
include 'phpqrcode/phpqrcode.php';
if($_SERVER['REQUEST_METHOD']=='POST')
{
    $gen=$_POST['gen'];
    $text=$gen;
    
    $file=uniqid().".png";
    $path='images/'.$file;
    $ecc='L';
    $pixel_Size= 6;
    $frame_size=10;

    QRcode:: png($text, $path, $ecc, $pixel_Size, $frame_size);

   $query="insert into qr(`qrtext`, `qrimg`) values('$text','$gen')";
   $data=mysqli_query($con,$query);
   if($data)
   {
    $_SESSION['success']= "<center><img src='$path'></center>";
    header('location:index.php');
   }
}
?>
 