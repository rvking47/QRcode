<?php
session_start();

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>QRCode Generator</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.6.2/dist/css/bootstrap.min.css">
  <script src="bootstrap.js"></script>
  <link rel="stylesheet" href="style.css">
</head>
<body>
    <div class="container">
        <div class="jumbotron my-5">
            <h2 class="text-center">- QRCode Generator -</h2>
    <form method="post" action="process.php">
        <label class="form-lable">Enter Content:</label>
        <input type="text" class="form-control" name="gen" placeholder="Enter Any Value To Generate"><br>
       <center> <input type="submit" name="create" class="btn btn-success" value="Submit"><br></center>
</div>
       </form>
    </div>
       <?php
       if(isset($_SESSION['success']))
       {
        ?>
             <div class="container">
        <div class="row">
        <div class="col-lg-4">
        <div class="jumbotron1">
        <?=$_SESSION['success'];?>
        <?php
       }unset($_SESSION['success']);
?>
    </div>
    </div>
    </div>
             </div>
</body>
</html>